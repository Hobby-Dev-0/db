
PLUGINS = []
ADDONS = []
HELP = {}
LOADED = {}
LIST = {}
