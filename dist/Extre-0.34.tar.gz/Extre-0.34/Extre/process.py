# Copyright Team EXTREMEPRO 2021 - 2022 


class CancelProcess(Exception):
    """
    Cancel Process
    """